﻿using Android.App;
using Android.OS;
using Android.Support.V4.App;

namespace Lab7Fragments
{
	[Activity(Label = "Lab 8 Data", MainLauncher = true, Icon = "@drawable/icon")]
	public class MainActivity : FragmentActivity
	{
		public static MainActivity context;

		protected override void OnCreate (Bundle bundle)
		{
			base.OnCreate (bundle);

			context = this;

			SetContentView (Resource.Layout.activity_main);

		}
	}
}