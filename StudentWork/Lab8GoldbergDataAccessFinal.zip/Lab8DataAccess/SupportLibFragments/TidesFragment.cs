using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Net;
using SQLite;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.Support.V4.App;


namespace Lab7Fragments
{
    internal class TidesFragment : Fragment
    {
		public static Tide[] tides;
		public static Tide[] dates;
		public TextView text;
		public ListView list;

		public static int selTide = 0;

        public static TidesFragment NewInstance(string name, string id, string state, int selStat)
        {
            var tidesFrag = new TidesFragment {Arguments = new Bundle()};
			tidesFrag.Arguments.PutInt("selStat", selStat);
			tidesFrag.Arguments.PutString("name", name);
			tidesFrag.Arguments.PutString("id", id);
			tidesFrag.Arguments.PutString("state", state);
            return tidesFrag;
		}

		public int selStat
		{
			get { return Arguments.GetInt("selStat", 0);}
			set {}
		}
		public string name
        {
			get { return Arguments.GetString("name");}
			set {}
        }
		public string id
		{
			get { return Arguments.GetString("id");}
			set{}
		}
		public string state
		{
			get { return Arguments.GetString("state");}
			set {}
		}

        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            if (container == null)
            {
                // Currently in a layout without a container, so no reason to create our view.
                return null;
            }
			// Create the layout for this Fragment
			var layout = new RelativeLayout(Activity);
			RelativeLayout.LayoutParams tParams = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.FillParent, ViewGroup.LayoutParams.WrapContent);
			RelativeLayout.LayoutParams lParams = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.FillParent, ViewGroup.LayoutParams.WrapContent);

			// Create the text view to display selected location, selected date, and tide info
            text = new TextView(Activity);
			text.LayoutParameters = tParams;

			var metrics = Resources.DisplayMetrics;
			var heightInDp = metrics.HeightPixels;
			int textViewHeight;
			if (heightInDp < 360) textViewHeight = 100;
			else textViewHeight = 150;

			text.SetHeight(textViewHeight);
			text.SetBackgroundColor(Android.Graphics.Color.LightCyan);
			text.SetTextColor(Android.Graphics.Color.Black);
			text.SetPadding(10, 0, 10, 0);
			layout.AddView(text);

			// Create the listview to display the dates
			list = new ListView(Activity);
			lParams.TopMargin = textViewHeight;
			list.LayoutParameters = lParams;

			var db = Database.OpenDatabase ("tides.db3");

			tides = db.Query<Tide> ("SELECT * FROM tides WHERE ID="+id).ToArray ();
			db.Close ();

			if (tides.Length > 1) 
			{
				dates = GetDates();
				string[] strDates = new string[dates.Length]; 
				for (int i = 0; i < dates.Length; i++)
				{
					strDates[i] = dates[i].getDate();
				}
				var adapter = new ArrayAdapter<String>(Activity, Android.Resource.Layout.SimpleListItemChecked, strDates);
		
				list.Adapter = adapter;
				list.ChoiceMode = ChoiceMode.Single;
				list.FastScrollEnabled = true;
				list.SetBackgroundColor (Android.Graphics.Color.DarkBlue);
				layout.AddView(list);

				list.ItemClick += (sender, e) => 
				{
					selTide = e.Position;
					DisplaySelectedTide();
				};
			}

			if (savedInstanceState != null)
			{
				selTide = savedInstanceState.GetInt("selTide", 0);
				name = savedInstanceState.GetString("name");
				id = savedInstanceState.GetString("id");
				state = savedInstanceState.GetString("state");
			}
			list.SetItemChecked(selTide, true);
			DisplaySelectedTide();

            return layout;
        }
		private int ConvertPixelsToDp(float pixelValue)
		{
			var dp = (int) ((pixelValue)/Resources.DisplayMetrics.Density);
			return dp;
		}

		public override void OnSaveInstanceState(Bundle outState)
		{
			base.OnSaveInstanceState(outState);
			outState.PutInt("selTide", selTide);
			outState.PutString("name", name);
			outState.PutString("id", id);
			outState.PutString("state", state);
		}
		public override void OnResume()
		{
			base.OnResume();
			list.SetSelection(selTide);
		}
		private void DisplaySelectedTide()
		{
			if (selTide > -1 && tides.Length >1)
			{
				var date = dates[selTide].date;
				// look for position of date in tides array
				int index = 0;
				int tideCount = 0;
				for (int i = 0; i < tides.Length; i++)
				{
					if (date == tides[i].date)
					{
						if (tideCount == 0) {
							index = i; // found it
							tideCount++;
						} else
							tideCount++;
					}
				}
				
				// Get handle to TextView to display daily tide info.

				text.Text = name + ", " + state + "\n"; // Show the location.
				text.Text += tides[index].getDate() + "\n";
				// Display the tides for the date.
				for (int i = index; i < index+tideCount; i++)
				{
					text.Text += tides[i].getTime() + ", " + tides[i].getHiLo() + ", " + tides[i].getHeights() + "\n";
				}
			}
		}

		// Get only unique dates from tides array.
		private Tide[] GetDates()
		{
			var dates = new List<Tide>();
			string date = "";
			string lastDate = "";
			for (int i=0; i< tides.Length; i++)
			{
				date = tides[i].date;
				// Only add the first tide per day to the dates list.
				if (date != lastDate) 
				{
					dates.Add(tides[i]);
				}
				lastDate = date;
			}
			// convert list to Tide array and send it back
			return dates.ToArray();;
		}
    }
}