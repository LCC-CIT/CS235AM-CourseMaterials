
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

//using Android.App;
//using Android.Content;
//using Android.OS;
//using Android.Runtime;
//using Android.Views;
//using Android.Widget;
using SQLite;

namespace Lab7Fragments
{
	[Table("tides")]
	public class Tide
	{
		[PrimaryKey, Column("key")]
		[AutoIncrement]
		public int key {get; set;}
		[MaxLength(10)]
		public string date {get;set;} //yyyy/mm/dd
		[MaxLength(8)]
		public string time {get;set;} //hh:mm AM (or PM)
		[MaxLength(7)]
		public string ID {get;set;} 
		[MaxLength(9)]
		public string day {get;set;} // full day name
		[MaxLength(5)]
		public string heightFt {get;set;}
		[MaxLength(5)]
		public string heightCm {get;set;}
		[MaxLength(4)]
		public string hiLo {get;set;} // High or Low




		// Returns date in the form "Tuesday, Jan 1".
		public string getDate()
		{
			string mon = getMonth();
			string da = date.Substring(8,2);
			if (da[0] == '0') da = da.Replace("0","");

			return day + ", " + mon + " " + da;
		}

		// Returns full month name
		public string getMonth()
		{
			string mon;
			var key = date.Substring(5,2);
			switch (key)
			{
			case "01":
				mon = "January";
				break;
			case "02":
				mon = "February";
				break;
			case "03":
				mon = "March";
				break;
			case "04":
				mon = "April";
				break;
			case "05":
				mon = "May";
				break;
			case "06":
				mon = "June";
				break;
			case "07":
				mon = "July";
				break;
			case "08":
				mon = "August";
				break;
			case "09":
				mon = "September";
				break;
			case "10":
				mon = "October";
				break;
			case "11":
				mon = "November";
				break;
			case "12":
				mon = "December";
				break;
			default:
				mon = "???";
				break;
			}
			return mon;
		}

		// Returns Tide info in the form "High" or "Low"
		public string getHiLo()
		{
			return hiLo;
		}

		// Returns tide height in the form "(ft): 1.0 (cm): 24"
		public string getHeights()
		{
			string info ="(ft): " + heightFt;
			info += " (cm): " + heightCm;
			return info;
		}

		// Returns time in the form "01:10 AM"
		public string getTime()
		{
			return time;
		}

		// Returns the full day name
		public string getDay()
		{
			return day;
		}
	}
}

