using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Net;
using SQLite;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;



namespace Lab7Fragments
{
	class Database
	{
		public static SQLiteConnection OpenDatabase(string filename)
		{
			var dbPath = Path.Combine (System.Environment.GetFolderPath (System.Environment.SpecialFolder.Personal), filename);

			if (!File.Exists (dbPath)) 
			{
				using (Stream inStream = MainActivity.context.Assets.Open (filename))
				using (Stream outStream = File.Create (dbPath))
				inStream.CopyTo (outStream);

			}

			var db = new SQLiteConnection (dbPath);
			return db;
		}
	}
}

