using System;
using SQLite;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Net;
using System.Linq;

namespace Lab7Fragments
{
	class MainClass
	{
		public static void Main ()
		{
			string[] usStates = {"AL","PR","VI","AK","AZ","AR","CA","CO","CT","DE","DC","FL","GA","HI","ID","IL","IN","IA","KS","KY","LA","ME","MD","MA","MI","MN","MS","MO","MT","NE","NV","NH","NJ","NM","NY","NC","ND","OH","OK","OR","PA","RI","SC","SD","TN","TX","UT","VT","VA","WA","WV","WI","WY"};
			//string[] usStates = {"HI","OR"}; // Only get HI and OR tides

			Console.WriteLine ("Hello Data!");

			string dbPath = Path.Combine (Environment.GetFolderPath (Environment.SpecialFolder.Personal), "stations.db3");
			//if (File.Exists(dbPath)) 
			//{
			//	File.Delete (dbPath);
			//}

			// Open or create a database
			var db = new SQLiteConnection (dbPath);
			 
			if (db.CreateTable<Station>() == 0)
			{
				// A table already exixts, delete any data it contains
				db.DeleteAll<Station>();
			}

			// Set URLs and instantiate needed objects for web access
			string baseURL = "http://tidesandcurrents.noaa.gov/";
			string statListURL = "station_retrieve.shtml?type=Tide%20Data&state=All%20Stations&id1=";
			Stream data;
			WebClient client = new WebClient();

			// Open a read stream to the URL
			data = client.OpenRead (baseURL + statListURL);

			// Open a reader to read the stream
			StreamReader reader = new StreamReader(data);
			
			string str = "";

			for (int i = 0; i < 159; i++) // skip early lines, line 158 causes an exception, dunno why and don't care
			{
				str = reader.ReadLine ();
			}
			for (int i = 0; i < 500; i++) // no need to read more than necessary to get the station data I want
			{
				str = reader.ReadLine ();
				if (str.Contains("data_menu.shtml?stn=")) // look for lines with station data
				{

					string[] fields = str.Split ("><".ToCharArray()); // Split the line into fields used to populate the next Station Object
					
					var stat = new Station();
					stat.ID = fields[4];
					stat.Name = fields[8]; 
					if (usStates.Contains (stat.Name.Substring (stat.Name.Length-2))) // Only add US states, PR and VI tides
					{
						stat.State = stat.Name.Substring (stat.Name.Length-2);
						stat.Name = stat.Name.Substring(0, stat.Name.Length-4);
						db.Insert (stat);
						Console.WriteLine(stat.Name + ", " + stat.State + ", ID: " + stat.ID);
					}
				}
			}
			reader.Close();

			var stations = db.Table<Station>();
			Console.WriteLine("Number of Station Rows Inserted = {0}", stations.Count());

			string dbPathTides = Path.Combine (Environment.GetFolderPath(Environment.SpecialFolder.Personal), "tides.db3");
			//if (File.Exists(dbPathTides)) 
			//{
			//	File.Delete (dbPathTides);
			//}
			var dbTide = new SQLiteConnection (dbPathTides);

			if (dbTide.CreateTable<Tide>() == 0)
			{
				// A table already exixts, delete any data it contains
				dbTide.DeleteAll<Tide>();
			}

			string tideData = "";

			// Load Tide data for each station into tide table.
			foreach (Station station in stations)
			{

				string tideBaseURL = "http://tidesandcurrents.noaa.gov/";
				string tideListURL = "noaatidepredictions/NOAATidesFacade.jsp?datatype=Annual+TXT&Stationid=";        
				tideListURL += station.ID; // set station ID
				
				WebClient clientTide = new WebClient();

				Stream dataTide;
				try
				{
					dataTide = clientTide.OpenRead (tideBaseURL + tideListURL);
				}
				catch // error code was returned, this means the station has no tide data, so delete the station from the database and move to the next.
				{
					db.Delete(station);
					continue;
				}
				StreamReader readerTide = new StreamReader(dataTide);

				while (!readerTide.EndOfStream)
				{
					// Read line of text file.
					tideData = readerTide.ReadLine();
					var currDateTime = DateTime.Now;

					// If it doesn't start with "2", move on
					if (tideData.Substring(0,1) != "2")
						continue;
					else if (tideData.Substring(0,4) != "2013")
						continue;
					else if (Convert.ToInt32(tideData.Substring(5,2)) < currDateTime.Month) // Get only this and future months
						continue;

					// Create new tide object
					var tide = new Tide();

					tide.date = tideData.Substring(0,10);
					
					switch (tideData.Substring(11,3))
					{
					case "Sun":
						tide.day = "Sunday";
						break;
					case "Mon":
						tide.day = "Monday";
						break;
					case "Tue":
						tide.day = "Tuesday";
						break;
					case "Wed":
						tide.day = "Wednesday";
						break;
					case "Thu":
						tide.day = "Thursday";
						break;
					case "Fri":
						tide.day = "Friday";
						break;
					case "Sat":
						tide.day = "Saturday";
						break;
					}
					
					tide.time = tideData.Substring(15,8);
					
					tide.ID = station.ID;
					
					string[] tideFields = tideData.Split(' ','\t');
					tide.heightFt = tideFields[4];
					tide.heightCm = tideFields[6];
					
					tide.hiLo = tideData.Substring(tideData.Length-1);
					if (tide.hiLo == "H")
						tide.hiLo = "High";
					else
						tide.hiLo = "Low";

					dbTide.Insert(tide);
					Console.WriteLine (tide.date + ", " + tide.day + " " + tide.time + " " + tide.hiLo + " " + tide.heightFt + " " + tide.heightCm);

				}
				readerTide.Close ();
				var tides = dbTide.Table<Tide> ();
				Console.WriteLine("Number of Tide Rows Inserted: {0}, Name: {1}, {2}, ID: {3}", tides.Count(), station.Name, station.State, station.ID);
			}
			Console.WriteLine("Final number of stations with data: {0}", stations.Count());

			var st = db.Table<Station> ().ToArray ();
			foreach (Station s in st) 
			{
				Console.WriteLine (s.Name + " " + s.State + " " + s.ID);
				var ti = dbTide.Query<Tide> ("SELECT * FROM tides WHERE ID=" + s.ID).ToArray ();
				foreach (Tide t in ti) 
				{
					Console.WriteLine (t.key + " " + t.getDate() + " " + t.getTime() + " " + t.getHiLo() + " " + t.getHeights());
				}
			}

			db.Close ();
			dbTide.Close ();
		}
	}
}
