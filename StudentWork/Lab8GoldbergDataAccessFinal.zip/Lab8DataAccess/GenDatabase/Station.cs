
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

//using Android.App;
//using Android.Content;
//using Android.OS;
//using Android.Runtime;
//using Android.Views;
//using Android.Widget;
using SQLite;

namespace Lab7Fragments
{
	[Table("stations")]
	public class Station
	{
		[PrimaryKey, Column("ID")]
		[MaxLength(8)]
		public string ID {get;set;}
		[MaxLength(100)]
		public string Name {get;set;}
		[MaxLength(2)]
		public string State {get;set;}
	}
}

