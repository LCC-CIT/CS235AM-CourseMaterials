using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Tides_SqLite;

namespace Tides_WithSqLite
{
	[Activity (Label = "TidesActivity")]			
	public class TidesActivity : Activity
	{
		protected override void OnCreate (Bundle bundle)
		{
			base.OnCreate (bundle);

			var location = Intent.Extras.GetString ("location");

			var tides = TidesFragment.NewInstance (location);
			var fragmentTransaction = FragmentManager.BeginTransaction ();
			fragmentTransaction.Add (Android.Resource.Id.Content, tides);
			//fragmentTransaction.Add (Android.Resource.Id.List, tides);
			//breaks down herej\
			fragmentTransaction.Commit ();		
		}
	}
}

