using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace Tides_SqLite
{
	[Activity (Label = "DetailsActivity")]			
	public class DetailsActivity : Activity
	{
		protected override void OnCreate (Bundle bundle)
		{
			base.OnCreate (bundle);
			//var index = Intent.Extras.GetInt ("selected_position", 0);
			var date = Intent.Extras.GetString ("details");

			var details = DetailsFragment.NewInstance (date);
			var fragmentTransaction = FragmentManager.BeginTransaction ();
			fragmentTransaction.Add (Android.Resource.Id.Content, details);
			fragmentTransaction.Commit ();
			// Create your application here
		}
	}
}

