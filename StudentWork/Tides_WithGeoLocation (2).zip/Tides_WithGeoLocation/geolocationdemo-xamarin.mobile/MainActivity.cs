using System;
using Android.App;
using Android.Content;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.OS;
using System.IO;
using SQLite;
using Tides_SqLite;
using DataAccess;
using Tides_WithSqLite;
using GeolocationDemoxamarin.mobile;

#if USE_SUPPORT
using Android.Support.V4.App;
using FragmentUsingSupport;
#endif

namespace Tides_SqLite
{
	[Activity (Label = "Tides_SqLite")]
	#if USE_SUPPORT
	public class MainActivity :FragmentActivity
	#else
	public class MainActivity : Activity
	#endif
	{
		protected override void OnCreate (Bundle bundle)
		{
			base.OnCreate (bundle);
			SetContentView (Resource.Layout.activity_main);
		}
	}
}