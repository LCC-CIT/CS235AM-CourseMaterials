using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using SQLite;
using Android.App;

namespace DataAccess {

	[Table("Tides")]
	public class Tide {
		[PrimaryKey, AutoIncrement, Column("_id")]
		public int Id { get; set; }

		//[MaxLength(8)]
		public string StationId { get; set; }
		public DateTime TideDate { get; set; }
		public string TideDay	{ get; set; }
		public string Time { get; set; }
		public string Feet { get; set; }
		public string Cm { get; set; }
		public string HighLow { get; set; }

	}
	[Table ("Locations")]
	public class Locations
	{
		[PrimaryKey, Column("_id")]
		public string Id { get; set; }
		public string Location { get; set; }
		public string Latitude { get; set; }
		public string Longitude { get; set; }
	}

}
