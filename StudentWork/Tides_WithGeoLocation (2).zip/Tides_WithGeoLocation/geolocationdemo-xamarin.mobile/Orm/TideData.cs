using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Xml.Serialization;

namespace Tides_WebService
{
	[Serializable]
	public class datainfo
	{
		[XmlElement]
		public object origin { get; set; }
		[XmlElement]
		public object disclaimer { get; set; }
		[XmlElement]
		public object producttype { get; set; }
		[XmlElement]
		public string stationname { get; set; }
		[XmlElement]
		public object state { get; set; }
		[XmlElement]
		public string stationid { get; set; }
		[XmlElement]
		public object stationtype { get; set; }
		[XmlElement]
		public object referencedToStationName { get; set; }
		[XmlElement]
		public object referencedToStationId { get; set; }
		[XmlElement]
		public object HeightOffsetLow { get; set; }
		[XmlElement]
		public object HeightOffsetHigh { get; set; }
		[XmlElement]
		public object TimeOffsetLow { get; set; }
		[XmlElement]
		public object TimeOffsetHigh { get; set; }
		[XmlElement]
		public object BeginDate { get; set; }
		[XmlElement]
		public object EndDate { get; set; }
		[XmlElement]
		public object dataUnits { get; set; }
		[XmlElement]
		public object Timezone { get; set; }
		[XmlElement]
		public object Datum { get; set; }
		[XmlElement]
		public object IntervalType { get; set; }
		[XmlElement]
		public data data { get; set; }

	}
	[Serializable]
	public class data
	{
		[XmlElement]
		public List<item> item { get; set; }
	}
	[Serializable]
	public class item
	{
		[XmlElement]
		public string date { get; set; }
		[XmlElement]
		public string day { get; set; }
		[XmlElement]
		public string time { get; set; }
		[XmlElement]
		public string predictions_in_ft { get; set; }
		[XmlElement]
		public string predictions_in_cm { get; set; }
		[XmlElement]
		public string highlow { get; set; }
	}

}

