using System;
using System.IO;
using System.Net;
using System.Xml.Serialization;
using System.Xml;
using DataAccess;
using SQLite;

namespace Tides_WebService
{
	public class TideApiClient
	{
		public void GetTideData(string stationId)
		{
			datainfo tideData;
			var url = @"http://tidesandcurrents.noaa.gov/noaatidepredictions/NOAATidesFacade.jsp?datatype=Annual+XML&Stationid=" + stationId;
			//var url = "http://www.tidesandcurrents.noaa.gov/noaatidepredictions/NOAATidesFacade.jsp?Stationid=9431647";
			//synchronous consumption
			string dbPath = Path.Combine (System.Environment.GetFolderPath (System.Environment.SpecialFolder.Personal), "oregonTides.db3");
			var db = new SQLiteConnection (dbPath);
			//db.CreateTable<Tide> ();
			//if the table is empty or the table does not contain the stationid already

				WebClient syncClient = new WebClient();
				var content = syncClient.DownloadString (url);

				XmlSerializer serializer = new XmlSerializer(typeof(datainfo));

				using (XmlReader reader = XmlReader.Create(new StringReader(content)))
				{
					// deserialize the XML object using the WeatherData type
					tideData = (datainfo)serializer.Deserialize(reader);

				}

				
			foreach (item item in tideData.data.item) 
				{
					var newTide = new Tide ();
					//automatic initialization
					newTide.StationId = tideData.stationid;
					newTide.TideDate = DateTime.Parse (item.date);
					newTide.TideDay = item.day;
					newTide.Time = item.time;
					newTide.Feet = item.predictions_in_ft;
					newTide.Cm = item.predictions_in_cm;
					newTide.HighLow = item.highlow;
					db.Insert (newTide);
				}

		}
		//this works in the cosole app to ready the dates, etc.

	}
}

