using System;
using Android.App;
using Android.Content;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.OS;
using Xamarin.Geolocation;
using System.Threading.Tasks;
using Tides_SqLite;
using GeolocationDemoxamarin.mobile;
using System.IO;
using SQLite;
using DataAccess;
using Tides_WebService;

namespace Tides_WithGeolocation
{
	[Activity (Label = "Tides_WithGeolocation", MainLauncher = true)]
	public class FirstActivity : Activity
	{
		string dbPath = Path.Combine (System.Environment.GetFolderPath (System.Environment.SpecialFolder.Personal), "oregonTides.db3");

		protected override void OnCreate (Bundle bundle)
		{
			base.OnCreate (bundle);

			// Set our view from the "main" layout resource
			SetContentView (Resource.Layout.First);

			// Get our button from the layout resource,
			// and attach an event to it
			var locator = new Geolocator(this) { DesiredAccuracy = 50 };

			//query to check for date and location in db
			var db = new SQLiteConnection (dbPath);

			//TODO:  create query that returns data for dates that = selected date and output string here
			db.CreateTable<Locations> ();
			db.CreateTable<Tide> ();
			//THIS DOESN'T WORK. IF I COULD GET THIS TO WORK, PRETTY SURE i CAN QUERY THE LOCATION TABLE TO GET THE DATA I NEED FOR THE REST
			/*
			string lat = locator.GetPositionAsync (timeout: 100000).Result.Latitude.ToString ();
			string lon = locator.GetPositionAsync (timeout: 100000).Result.Longitude.ToString();
			//query to test for location in table
			var query2 = db.Query<Locations> ("SELECT location FROM [Locations] WHERE latitude = ?", lat, "AND longitude = ?", lon);

			//if the table is not there or empty or cannot return location then need to use tideapi to load table and return info
			if (db.Table<Locations> ().Count () == 0 ||query2.Count == 0) 
			{
				TideApiClient client = new TideApiClient ();
				//query to get stationId from lat/long
				string stationId = query2.ToString ();
				client.GetTideData (stationId);
			}
			//else, need to query table and return results
			//string to output date into textview
			
			*/
			//TODO:  get stationid from location table
			string stationId = "9434032";
			DateTime today = DateTime.Now.Date;
			var q = db.Query<Tide> ("SELECT TideDate, HighLow, Time, Feet FROM [Tides] WHERE StationId = ?", stationId, "AND TideDate = ?", today);
			string s = "";
			if (q.Count > 0) {
				foreach (var t in q) {
					s += t.HighLow + ":  " + t.Time + " " + t.Feet + " ft" + "\r\n";
				}
			} else
				s = "Data for that location doesn't exist in the table, will load soon.";
			TextView view = FindViewById<TextView> (Resource.Id.details);
			view.Text = s;

			Button button = FindViewById<Button> (Resource.Id.myButton);

			button.Click += delegate 
			{

				locator.GetPositionAsync (timeout: 10000).ContinueWith (t => {
					button.Text = String.Format("Time: {0}\n", t.Result.Timestamp);
					button.Text += String.Format("Latitude: {0}\n", t.Result.Latitude);
					button.Text += String.Format("Longitude: {0}\n", t.Result.Longitude);
				}, TaskScheduler.FromCurrentSynchronizationContext());
				button.Text = "waiting...";

			};
			//button to launch fragment activities from tide app
			Button go = FindViewById<Button> (Resource.Id.choices);

			go.Click += (sender, e) => StartActivity (typeof(MainActivity));
		}


	}
}


