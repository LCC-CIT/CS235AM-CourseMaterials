using System;
using System.Collections.Generic;
//using System.Linq;
using System.Text;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Util;
using Android.Views;
using Android.Widget;
using System.IO;
using DataAccess;
using SQLite;
using Tides_WithSqLite;
using Tides_WebService;
using GeolocationDemoxamarin.mobile;

#if USE_SUPPORT
using Android.Support.V4.App;
using FragmentUsingSupport;
#else
using Android.App;
#endif

namespace Tides_SqLite
{
	//need to get the arguments out and convert OnActivityCreated to OnCreateView
	internal class TidesFragment : Android.App.ListFragment
	{
		private int position;
		bool _isDualPane;
		List<DateTime> tideDates;
		string tideInfo;
		string dbPath = Path.Combine (System.Environment.GetFolderPath (System.Environment.SpecialFolder.Personal), "oregonTides.db3");

		public override void OnActivityCreated(Bundle savedinstanceState)
		{
			position = -1;
			base.OnActivityCreated (savedinstanceState);

			LoadTideList ();
			this.ListAdapter = new ArrayAdapter (Activity, Android.Resource.Layout.SimpleListItemChecked, tideDates);

			var detailsFrame = Activity.FindViewById<View> (Resource.Id.tides_fragment);
			_isDualPane = detailsFrame != null && detailsFrame.Visibility == ViewStates.Visible;
			if (_isDualPane) 
			{
				ListView.ChoiceMode = ChoiceMode.Single;

			}
		}

		public string GetTideInfo(int position)
		{
			//need to do some stuff here to get info from the table -- query
			var db = new SQLiteConnection (dbPath);

			string s = "Tide Data for " + tideDates[position].ToString("D") + "\r\n";
			//TODO:  create query that returns data for dates that = selected date and output string here
			var table = db.Table<Tide> ();
			var query2 = db.Query<Tide> ("SELECT TideDay, HighLow, Feet FROM [Tides] WHERE TideDate = ?", tideDates[position]);

			foreach (var info in query2) 
			{
				s += info.HighLow + ":  " + info.Feet + " ft \r\n";
			}
			return s;
		}

		public override void OnListItemClick(ListView l, View v, int p, long id)
		{
			tideInfo = GetTideInfo (p);
			ShowDetails (p);
		}
		//TODO:  create Locations table and add a tab or another activity or radio buttons to pick station
		private void LoadTideList()
		{
			if (Arguments == null) 
			{
				tideDates = new List<DateTime>();
			}
			else
			{
				//Get the xml stream associated with the clicked city
				var db = new SQLiteConnection (dbPath);
				db.CreateTable<Tide> ();
				TideApiClient client = new TideApiClient ();
				var q = db.Query<Tide> ("Select StationId from [Tides] where StationId = ?", Arguments.GetString("location"));
				if (q.Count == 0) 
				{
					client.GetTideData (Arguments.GetString ("location"));
			
					tideDates = new List<DateTime> ();

				}
				var table = db.Table<Tide> ();

				var query = db.Query<Tide> ("SELECT DISTINCT TideDate FROM [Tides] WHERE StationId = ?", Arguments.GetString ("location"));
				foreach (var s in query) 
				{
					tideDates.Add (s.TideDate);
				}
				db.Close ();
			}
		}
		private void ShowDetails(int tDate)
		{
			position = tDate;
			if (_isDualPane) 
			{
				ListView.SetItemChecked (tDate, true);
				var details = FragmentManager.FindFragmentById (Resource.Id.details) as DetailsFragment;
				if (details == null || details.ShownTideDate != tideInfo) {
					details = DetailsFragment.NewInstance (tideInfo);
					var ft = FragmentManager.BeginTransaction ();
					ft.Replace (Resource.Id.details, details);
					#if USE_SUPPORT
				ft.SetTransition(FragmentTransaction.TransitFragmentFade);	
					#else
					ft.SetTransition (FragmentTransit.FragmentFade);		
					#endif
					ft.Commit ();
				} else {
					var intent = new Intent ();
					intent.SetClass (Activity, typeof(DetailsActivity));
					intent.PutExtra("details", tideInfo);
					StartActivity (intent);
				}
			}
			else
			{
				// Otherwise we need to launch a new Activity to display
				// the dialog fragment with selected text.
				var intent = new Intent();
				intent.SetClass(Activity, typeof (DetailsActivity));		// Note: DetailsActivity needs to be added to the project but isn't described in the pdf
				intent.PutExtra("selected_position", position);
				intent.PutExtra ("details", tideInfo);
				StartActivity(intent);
			}
		}
		//putting arguments in
		public static TidesFragment NewInstance(string location)
		{
			var tidesFrag = new TidesFragment { Arguments = new Bundle () };
			tidesFrag.Arguments.PutString("location", location);

			return tidesFrag;
		}


	}
}

