using System;
using System.Collections.Generic;
//using System.Linq;
using System.Text;
using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Util;
using Android.Views;
using Android.Widget;
using System.IO;
#if USE_SUPPORT
using Android.Support.V4.App;
#endif


namespace Tides_SqLite
{

	#if USE_SUPPORT
	internal class DetailsFragment : Android.Support.V4.App.Fragment
	#else
	internal class DetailsFragment : Android.App.Fragment
	#endif
	{
		public static DetailsFragment NewInstance(string details)
		{
			var detailsFrag = new DetailsFragment { Arguments = new Bundle () };
			detailsFrag.Arguments.PutString("details", details);

			return detailsFrag;
		}
		public string ShownTideDate
		{
			get { return Arguments.GetString ("details"); }
		}
		public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
		{
			if (container == null) 
			{
				//currently in a layout without a container, so no reason to create our view
				return null;
			}
			var scroller = new ScrollView (Activity);
			var text = new TextView (Activity);
			var padding = Convert.ToInt32 (TypedValue.ApplyDimension (ComplexUnitType.Dip, 4, Activity.Resources.DisplayMetrics));
			text.SetPadding (padding, padding, padding, padding);
			text.TextSize = 24;

			text.Text = ShownTideDate;

			//array as property from class? [ShownTideDate];
			scroller.AddView (text);
			return scroller;
		}
	}
}

