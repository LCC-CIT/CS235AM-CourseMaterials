using System;
using System.Collections.Generic;
//using System.Linq;
using System.Text;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Util;
using Android.Views;
using Android.Widget;
using SQLite;
using DataAccess;
using System.IO;
using Tides_WithSqLite;
using GeolocationDemoxamarin.mobile;


#if USE_SUPPORT
using Android.Support.V4.App;
using FragmentUsingSupport;
#else
using Android.App;
#endif

namespace Tides_SqLite
{
	public class LocationsFragment : ListFragment
	{
		public override void OnCreate (Bundle savedInstanceState)
		{
			base.OnCreate (savedInstanceState);
		}

		private int position;
		//private bool _isDualPane;
		//TODO:  move tide stuff into MainActiity
		//set isDualPane to false to start
		List<String> stations;
		string location;
		string dbPath = Path.Combine (System.Environment.GetFolderPath (System.Environment.SpecialFolder.Personal), "oregonTides.db3");
		bool _isDualPane;

		public override void OnActivityCreated(Bundle savedinstanceState)
		{
			position = -1;
			base.OnActivityCreated (savedinstanceState);
			//Need to Load station list LoadTideList ();
			LoadStations ();
			//create a query that returns distinct TideDates
			//Custom cursor adapter?  
			ListAdapter = new ArrayAdapter(Activity, Android.Resource.Layout.SimpleListItemChecked, stations);

			if (savedinstanceState != null) 
			{
				//get the one saved
				position = savedinstanceState.GetInt ("selected_position", 0);
				location = savedinstanceState.GetString ("location", "");
			}

			var detailsFrame = Activity.FindViewById<View> (Resource.Id.tides_fragment);
			_isDualPane = detailsFrame != null && detailsFrame.Visibility == ViewStates.Visible;
			if (_isDualPane) 
			{
				ListView.ChoiceMode = ChoiceMode.Single;
			}
		}
		public override void OnListItemClick(ListView l, View v, int p, long id)
		{
			position = p;
			//Toast.MakeText(Activity, GetFileName (p).ToString(), ToastLength.Long).Show();
			location = GetFileName (p);
			ShowTideDates (p);
		}

		public string GetFileName(int position)
		{
			//need to do some stuff here to get info from the table -- query
			var db = new SQLiteConnection (dbPath);

			string s = "";
			//TODO:  create query that returns data for dates that = selected date and output string here
			var table = db.Table<Locations> ();
			var query2 = db.Query<Locations> ("SELECT _id FROM [Locations] WHERE Location = ?", stations[position]);

			foreach (var location in query2) 
			{
				s += location.Id;
			}

			return s;
		}
		public void LoadStations()
		{
			var db = new SQLiteConnection (dbPath);
			db.CreateTable<Locations> ();
			if (db.Table<Locations> ().Count() == 0) 
			 {
				string content;

				using (StreamReader sr = new StreamReader (Activity.Assets.Open (@"OregonTideStations.txt")))
					content = sr.ReadToEnd ();
				String[] lines = content.Split (new Char[] { '\r' });

				for (int i = 0; i < lines.Length; i++) {
					string[] split = lines [i].Split (new char[] { '\t' });
					var newLocation = new Locations ();
					//automatic initialization
					newLocation.Id = split [1];
					newLocation.Location = split [0];
					newLocation.Latitude = split [2];
					newLocation.Longitude = split [3];
					db.Insert (newLocation);

				}	
			}
			stations = new List<String>();

			var query = db.Query<Locations> ("SELECT DISTINCT Location FROM [Locations]");
			foreach (var s in query) 
			{
				stations.Add(s.Location);
			}
		}

		//List<DateTime> tideDates;
		private void ShowTideDates(int position)
		{
			if (_isDualPane) 
			{
				var tides = new TidesFragment() { Arguments = new Bundle () };
				tides.Arguments.PutString("location", location);

				var ft = FragmentManager.BeginTransaction(); 
				ft.Replace(Resource.Id.tides_fragment, tides);
				ft.SetTransition(FragmentTransit.FragmentFade);		
				ft.Commit();
			} 
			else
			{
				// Otherwise we need to launch a new Activity to display
				// the dialog fragment with selected text.
				var intent = new Intent();
				intent.SetClass(Activity, typeof (TidesActivity));		// Note: DetailsActivity needs to be added to the project but isn't described in the pdf
				intent.PutExtra ("location", location);
				StartActivity(intent);
			}
		}
	}
}

