using System;

using Android.App;
using Android.Content;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.OS;

using RpsLogic;

namespace rockpaperscissors
{
	[Activity (Label = "Rock, Paper, and Scissors", MainLauncher = true)]
	public class Activity1 : Activity
	{

		Rps rps = new Rps();

		protected override void OnCreate (Bundle bundle)
		{
			base.OnCreate (bundle);

			// Set our view from the "main" layout resource
			SetContentView (Resource.Layout.Main);

			// Get references to layout items
			var bRock = FindViewById<Button> (Resource.Id.button1);
			var bPaper = FindViewById<Button> (Resource.Id.button2);
			var bScissors = FindViewById<Button> (Resource.Id.button3);
			var compImage = FindViewById<ImageView> (Resource.Id.compImage);

			// store initial image height as set by screen size
			rps.imgHt = compImage.LayoutParameters.Height;

			// Generate computers move
			rps.ComputerChoose();

			// Click event handlers
			bRock.Click += (sender, e) => {
				rps.PlayerChoose(rpsChoice.rock);

				var winner = rps.whoWon();
				showWinner(winner);

				// Next computer move
				rps.ComputerChoose();
			};
			bPaper.Click += (sender, e) => {
				rps.PlayerChoose(rpsChoice.paper);

				var winner = rps.whoWon();
				showWinner(winner);

				// Next computer move
				rps.ComputerChoose();
			};
			bScissors.Click += (sender, e) => {
				rps.PlayerChoose(rpsChoice.scissors);

				var winner = rps.whoWon();
				showWinner(winner);

				// Next computer move
				rps.ComputerChoose();
			};
			 
		}

		void showWinner(winner winner) {
			// Dislay results
			var textView = FindViewById<TextView> (Resource.Id.textView1);
			textView.Text = GetString(Resource.String.winner) + winner;
			textView.Text +="\n" + GetString(Resource.String.w) + rps.pWins + GetString(Resource.String.l) + rps.cWins + GetString(Resource.String.t) + rps.ties;

			// Display images
			var compImage = FindViewById<ImageView> (Resource.Id.compImage);
			var playerImage = FindViewById<ImageView> (Resource.Id.playerImage);

			int[] imgResources = new int[3];
			imgResources[0] = Resource.Drawable.Rock;
			imgResources[1] = Resource.Drawable.Paper;
			imgResources[2] = Resource.Drawable.Scissors;

			compImage.SetImageResource(imgResources[(int)rps.compChoice]);
			playerImage.SetImageResource(imgResources[(int)rps.playerChoice]);

			// Adjust image size based on winner
			if (winner == winner.Computer) {
				compImage.LayoutParameters.Height = (int)Math.Round(rps.imgHt * 1.4);
				playerImage.LayoutParameters.Height = (int)Math.Round(rps.imgHt * .6);
			}
			else if (winner == winner.Player){
				playerImage.LayoutParameters.Height = (int)Math.Round(rps.imgHt * 1.4);
				compImage.LayoutParameters.Height = (int)Math.Round(rps.imgHt * .6);
			}
			else {
				playerImage.LayoutParameters.Height = rps.imgHt;
				compImage.LayoutParameters.Height = rps.imgHt;
			}
		}
	}
}


