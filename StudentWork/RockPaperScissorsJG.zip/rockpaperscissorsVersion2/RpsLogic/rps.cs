using System;

namespace RpsLogic
{
	public enum rpsChoice {rock, paper, scissors, none};
	public enum winner {Player, Computer, Tie};

	public class Rps
	{
		public rpsChoice playerChoice = rpsChoice.none;
		public rpsChoice compChoice = rpsChoice.none;
		public Random rnd = new Random();
		public int pWins = 0;
		public int cWins = 0;
		public int ties = 0;
		public int imgHt;

		public void PlayerChoose(rpsChoice ch) {
			playerChoice = ch;
		}
		public void ComputerChoose() {
			compChoice = (rpsChoice)rnd.Next(0,3);
		}

		public winner whoWon()
		{
			if (compChoice == playerChoice) {
				ties++;
				return winner.Tie;
			}
			else if (compChoice - playerChoice == 1 || compChoice - playerChoice == -2) {
				cWins++;
				return winner.Computer;
			}
			else {
				pWins++;
				return winner.Player;
			}
		}

	}
}

