using System;

namespace RpsLogic
{
	class MainClass
	{
		public static void Main (string[] args)
		{
			Rps rps = new Rps();

			Console.BackgroundColor = ConsoleColor.White;
			for (int i = 0; i < 50; i++) Console.WriteLine();
			Console.ForegroundColor = ConsoleColor.Black;

			ConsoleKeyInfo inp;

			while ((char)inp.Key != 'q' && (char)inp.Key != 'Q') {
				rps.ComputerChoose();

				Console.Write("Choose [R]ock, [P]aper, [S]cissors, or [Q]uit: ");

				inp = Console.ReadKey();

				switch ((char)inp.Key) {
				case 'r':
				case 'R':
					rps.PlayerChoose(rpsChoice.rock);
					break;
				case 'p':
				case 'P':
					rps.PlayerChoose(rpsChoice.paper);
					break;
				case 's':
				case 'S':
					rps.PlayerChoose(rpsChoice.scissors);
					break;
				case 'q':
				case 'Q':
					continue;
				default:
					Console.WriteLine();
					continue;
				}
				Console.WriteLine();
				Console.Write("Player threw ");
				Console.WriteLine(rps.playerChoice);
				Console.Write("Computer threw ");
				Console.WriteLine(rps.compChoice);

				Console.Write("The Winner is: ");
				var winner = rps.whoWon();
				if (winner == winner.Player) Console.ForegroundColor = ConsoleColor.Green;
				else if (winner == winner.Computer) Console.ForegroundColor = ConsoleColor.Red;
				Console.WriteLine(winner);

				Console.ForegroundColor = ConsoleColor.Black;
				Console.WriteLine("Wins: " + rps.pWins + ", Losses: " + rps.cWins + ", Ties: " + rps.ties);
				Console.WriteLine();
			}
		}
	}
}
