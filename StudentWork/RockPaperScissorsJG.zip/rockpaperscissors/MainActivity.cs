using System;

using Android.App;
using Android.Content;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.OS;

using RpsLogic;

namespace rockpaperscissors
{
	[Activity (Label = "Rock, Paper, and Scissors", MainLauncher = true)]
	public class Activity1 : Activity
	{

		Rps rps = new Rps();

		protected override void OnCreate (Bundle bundle)
		{
			base.OnCreate (bundle);

			// Set our view from the "main" layout resource
			SetContentView (Resource.Layout.Main);

			var bRock = FindViewById<ImageButton> (Resource.Id.button1);
			var bPaper = FindViewById<ImageButton> (Resource.Id.button2);
			var bScissors = FindViewById<ImageButton> (Resource.Id.button3);
			var textView = FindViewById<TextView> (Resource.Id.textView1);

			rps.ComputerChoice();

			textView.Text += GetString(Resource.String.waiting);

			bRock.Click += (sender, e) => {
				rps.PlayerChoice(0);
				showWinner();
			};
			bPaper.Click += (sender, e) => {
				rps.PlayerChoice(1);
				showWinner();
			};
			bScissors.Click += (sender, e) => {
				rps.PlayerChoice(2);
				showWinner();
			};
			 
		}

		void showWinner() {
			var winner = rps.whoWon();
			var textView = FindViewById<TextView> (Resource.Id.textView1);
			textView.Text = GetString(Resource.String.cSel) + (rpsChoice)rps.compChoice;
			textView.Text += "\n" + GetString(Resource.String.pSel) + (rpsChoice)rps.playerChoice;
			textView.Text +="\n" + GetString(Resource.String.winner) + winner;
			textView.Text +="\n" + GetString(Resource.String.w) + rps.pWins + GetString(Resource.String.l) + rps.cWins + GetString(Resource.String.t) + rps.ties;
			rps.ComputerChoice();
		}

	}
}


