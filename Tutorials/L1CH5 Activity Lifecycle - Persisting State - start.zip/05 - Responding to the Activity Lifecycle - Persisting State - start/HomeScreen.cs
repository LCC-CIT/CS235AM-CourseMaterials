namespace PersistStateWalkthrough
{
    using System;
    using System.Collections.Generic;
    using System.Threading;

    using Android.App;
    using Android.OS;
    using Android.Widget;

    using Object = Java.Lang.Object;

    [Activity(Label = "Persist State", MainLauncher = true, Icon = "@drawable/icon")]
    public class HomeScreen : Activity
    {
        private List<Flora> listOfFlora = new List<Flora>();
        private ListView listView;
        private TextView selectedFloraText;

        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);

            SetContentView(Resource.Layout.HomeScreen);
            listView = FindViewById<ListView>(Resource.Id.List);
            selectedFloraText = FindViewById<TextView>(Resource.Id.selected_flora);

            LoadFloraList();

            listView.Adapter = new HomeScreenAdapter(this, listOfFlora);
            listView.ItemClick += OnListItemClick;
        }

        protected void OnListItemClick(object sender, AdapterView.ItemClickEventArgs e)
        {
            var t = listOfFlora [e.Position];
            selectedFloraText.Visibility = Android.Views.ViewStates.Visible;
            selectedFloraText.Text = "Selected flora : " + t.Name;
        }

        private void LoadFloraList()
        {
            listOfFlora.Add(new Flora { Name = "Vegetables", ItemCount = "65 items", ImageResourceId = Resource.Drawable.Vegetables });
            listOfFlora.Add(new Flora { Name = "Fruits", ItemCount = "17 items", ImageResourceId = Resource.Drawable.Fruits });
            listOfFlora.Add(new Flora { Name = "Flower Buds", ItemCount = "5 items", ImageResourceId = Resource.Drawable.FlowerBuds });

            // Pretend that creating this list takes a long time.
            Thread.Sleep(2500);

            listOfFlora.Add(new Flora { Name = "Legumes", ItemCount = "33 items", ImageResourceId = Resource.Drawable.Legumes });
            listOfFlora.Add(new Flora { Name = "Bulbs", ItemCount = "18 items", ImageResourceId = Resource.Drawable.Bulbs });
            listOfFlora.Add(new Flora { Name = "Tubers", ItemCount = "43 items", ImageResourceId = Resource.Drawable.Tubers });
        }
    }
}
