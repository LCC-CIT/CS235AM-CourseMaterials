﻿
/*****  Although great care has gone into developing this finance web service using finance yahoo API,             ******/
/*****  It is provided without any guarantee of reliability, accuracy of information, or correctness of operation. ******/
/*****  I am not responsible for any damage that may occur as a result of using this program.                      ******/
/*****  Use this program entirely at your own risk.                                                                ******/
 
using System;
using System.Web;
using System.Web.Services;
using System.Net;
using System.Text;
using System.IO;
using System.Xml;


[WebService(Namespace = "http://stockdata.webservice.net.in", Description = "Get Stock Details - All Exchange", Name = "Stock Webservice")]
public class StockQuoteService : System.Web.Services.WebService
{
    public StockQuoteService()
    {
        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }

    [WebMethod]
    [System.Web.Script.Services.ScriptMethod(ResponseFormat = System.Web.Script.Services.ResponseFormat.Xml)]
    public string StockExists(string symbol)
    {
        if (symbol == "") return "";
        string[] arrStocks = symbol.Split(',');

        string uri = "http://download.finance.yahoo.com/d/quotes.csv?s=";

        //build the querystring value for "s"
        string sParam = string.Empty;
        foreach (string sStock in arrStocks)
        {
            if (sStock.Trim() != string.Empty)
            {
                sParam += sStock.Trim() + "+";
            }
        }
        if (sParam.Length > 0) sParam = sParam.TrimEnd('+');

        //build the querystring value for "f"
        string sOptions = string.Empty;

        //Symbol - s
        //Stock Exchange - x
        sOptions = "&f=sx";


        uri = uri + sParam + sOptions;
        string _ret = string.Empty;
        HttpWebRequest stockHttpWebRequest = null;
        StreamReader responseStream = null;

        try
        {
            stockHttpWebRequest = (HttpWebRequest)WebRequest.Create(uri);
            stockHttpWebRequest.MaximumAutomaticRedirections = 1;
            stockHttpWebRequest.AllowAutoRedirect = true;

            HttpWebResponse webresp = (HttpWebResponse)stockHttpWebRequest.GetResponse();

            // get the  response from the server.
            responseStream = new StreamReader(webresp.GetResponseStream(), Encoding.ASCII);

            //creating xml
            StringBuilder _xml = new StringBuilder();
            _xml.Append("<stock>");

            string strLine = responseStream.ReadLine();
            while (strLine != null)
            {
                string data = strLine.Replace("\"", "");
                string[] arrData = data.ToString().Split(',');

                _xml.Append("<symbol>");
                _xml.Append(string.Format("<code>{0}</code>", arrData[0]));

                if (arrData[1] == "N/A")
                    _xml.Append("<exchange>NA</exchange>");
                else
                    _xml.Append(string.Format("<exchange>{0}</exchange>", arrData[1]));
                _xml.Append("</symbol>");
                strLine = responseStream.ReadLine();
            }
            _xml.Append("</stock>");
            _ret = _xml.ToString();
            _xml = null;
        }
        catch (Exception)
        {
            return "exception";
        }
        finally
        {
            if (responseStream != null) { responseStream.Close(); responseStream.Dispose(); }
            stockHttpWebRequest = null;
        }
        return _ret;
    }

    [WebMethod]
    [System.Web.Script.Services.ScriptMethod(ResponseFormat = System.Web.Script.Services.ResponseFormat.Xml)]
    public string GetStockQuote(string symbol)
    {
        if (symbol == "") return "";
        string[] arrStocks = symbol.Split(',');

        string uri = "http://download.finance.yahoo.com/d/quotes.csv?s=";

        //build the querystring value for "s"
        string sParam = string.Empty;
        foreach (string sStock in arrStocks)
        {
            if (sStock.Trim() != string.Empty)
            {
                sParam += sStock.Trim() + "+";
            }
        }
        if (sParam.Length > 0) sParam = sParam.TrimEnd('+');

        //build the querystring value for "f"
        string sOptions = string.Empty;

        //Symbol - s
        //Stock Exchange - x
        //Name of the company - n
        //Last Price- l1
        //day's high - h 
        //day's low - g
        //open - o 
        //previous close - p
        //currency - 
        //change & change percent - c
        //Last Volume - v
        //Market Cpitalization - j1

        sOptions = "&f=sxnl1hgopcvj1";

        uri = uri + sParam + sOptions;
        string _ret = string.Empty;
        HttpWebRequest stockHttpWebRequest = null;
        StreamReader responseStream = null;

        try
        {
            stockHttpWebRequest = (HttpWebRequest)WebRequest.Create(uri);
            stockHttpWebRequest.MaximumAutomaticRedirections = 1;
            stockHttpWebRequest.AllowAutoRedirect = true;

            HttpWebResponse webresp = (HttpWebResponse)stockHttpWebRequest.GetResponse();

            // get the  response from the server.
            responseStream = new StreamReader(webresp.GetResponseStream(), Encoding.ASCII);

            //creating xml
            StringBuilder _xml = new StringBuilder();
            _xml.Append("<stock>");

            string strLine = responseStream.ReadLine();
            while (strLine != null)
            {
                string data = strLine.Replace("\"", "");
                string[] arrData = data.ToString().Split(',');

                _xml.Append("<symbol>");
                _xml.Append(string.Format("<code>{0}</code>", arrData[0]));

                if (arrData[1] == "N/A")
                {
                    _xml.Append("<exchange>NA</exchange>");
                }
                else
                {
                    _xml.Append(string.Format("<exchange>{0}</exchange>", arrData[1]));
                    _xml.Append(string.Format("<company>{0}</company>", arrData[2]));
                    _xml.Append(string.Format("<currency>{0}</currency>", ""));
                    _xml.Append(string.Format("<last>{0}</last>", arrData[3]));
                    _xml.Append(string.Format("<high>{0}</high>", arrData[4]));
                    _xml.Append(string.Format("<low>{0}</low>", arrData[5]));
                    _xml.Append(string.Format("<open>{0}</open>", arrData[6]));
                    _xml.Append(string.Format("<previousclose>{0}</previousclose>", arrData[7]));

                    string sChange = arrData[8];
                    if (sChange.Length > 0)
                    {
                        string[] arrChange = sChange.Split(' ');
                        if (arrChange.Length >= 2)
                        {
                            _xml.Append(string.Format("<change>{0}</change>", arrChange[0]));
                            _xml.Append(string.Format("<changepercent>{0}</changepercent>", arrChange[2]));
                        }
                        else
                        {
                            _xml.Append(string.Format("<change>{0}</change>", sChange));
                            _xml.Append(string.Format("<changepercent>{0}</changepercent>", "NA"));
                        }
                    }
                    _xml.Append(string.Format("<volume>{0}</volume>", arrData[9]));
                    _xml.Append(string.Format("<marketcapital>{0}</marketcapital>", arrData[10]));
                    _xml.Append(string.Format("<tradetime>{0}</tradetime>", "NA"));
                }
                _xml.Append("</symbol>");


                strLine = responseStream.ReadLine();
            }
            _xml.Append("</stock>");
            _ret = _xml.ToString();
            _xml = null;
        }
        catch (Exception)
        {
            return "exception";
        }
        finally
        {
            if (responseStream != null) { responseStream.Close(); responseStream.Dispose(); }
            stockHttpWebRequest = null;
        }
        return _ret;
    }

    [WebMethod]
    [System.Web.Script.Services.ScriptMethod(ResponseFormat = System.Web.Script.Services.ResponseFormat.Xml)]
    public byte[] GetStckChart(string symbol, string chartparam)
    {
        if (symbol == "") return null;
        string uri = "http://ichart.finance.yahoo.com";
        string _ret = string.Empty;

        //get a new gui for version
        string str_guid_ver = Guid.NewGuid().ToString();

        switch (chartparam)
        {
            case "1D":
                uri += string.Format("/b?s={0}", symbol);
                break;
            case "5D":
                uri += string.Format("/w?s={0}", symbol);
                break;
            case "3M":
                uri += string.Format("/c/3m/{0}?version={1}", symbol, str_guid_ver);
                break;
            case "6M":
                uri += string.Format("/c/6m/{0}?version={1}", symbol, str_guid_ver);
                break;
            case "1Y":
                uri += string.Format("/c/1y/{0}?version={1}", symbol, str_guid_ver);
                break;
            case "2Y":
                uri += string.Format("/c/2y/{0}?version={1}", symbol, str_guid_ver);
                break;
            case "5Y":
                uri += string.Format("/c/5y/{0}?version={1}", symbol, str_guid_ver);
                break;
            default:
                uri = "NA";
                break;
        }

        if (uri == "NA")
        {
            return null;
        }
        HttpWebRequest myHttpWebRequest = null;
        MemoryStream memoryStream = null;
        try
        {
            myHttpWebRequest = (HttpWebRequest)WebRequest.Create(uri);
            myHttpWebRequest.MaximumAutomaticRedirections = 1;
            myHttpWebRequest.AllowAutoRedirect = true;

            memoryStream = new MemoryStream(0x10000);
            
            using (Stream responseStream = myHttpWebRequest.GetResponse().GetResponseStream())
            {
                byte[] buffer = new byte[0x1000];
                int bytes;
                while ((bytes = responseStream.Read(buffer, 0, buffer.Length)) > 0)
                {
                    memoryStream.Write(buffer, 0, bytes);
                }
            }
            byte[] response = memoryStream.ToArray();
            return response;
        }
        catch (Exception)
        {
            return null;
        }
        finally
        {
            memoryStream.Close();
            memoryStream.Dispose();
            myHttpWebRequest = null;
        }
    }
}
