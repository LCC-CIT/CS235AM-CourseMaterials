using System;

using Android.App;
using Android.Content;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.OS;

namespace RockPaperScissors
{
	[Activity (Label = "RockPaperScissors", MainLauncher = true)]
	public class Activity1 : Activity
	{
		protected override void OnCreate (Bundle bundle)
		{
			base.OnCreate (bundle);

			// Set our view from the "main" layout resource
			SetContentView (Resource.Layout.Main);

			// Get our button from the layout resource,
			// and attach an event to it
			Button rockButton = FindViewById<Button> (Resource.Id.rockButton);

			var rps = new RpsLogic.Rps();

			rockButton.Click += delegate {
				rps.PlayerChoice = RpsLogic.rpsChoice.scissors;
				rockButton.Text = string.Format ( rps.PlayerChoice.ToString () );
			};
		}
	}
}


