using System;
using RpsLogic;

namespace RpsTest
{
	class MainClass
	{
		public static void Main (string[] args)
		{
			Rps rps = new Rps();
			rps.HumanChoice = Choice.rock;
			Console.WriteLine ( rps.HumanChoice.ToString () );
		}
	}
}
