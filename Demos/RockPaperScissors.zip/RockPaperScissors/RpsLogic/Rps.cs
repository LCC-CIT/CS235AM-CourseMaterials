using System;

namespace RpsLogic
{
	public enum Player {none, computer, human, both};
	public enum Choice {none, rock, paper, scissors};

	public class Rps
	{
		public Choice CompChoice {get; set;}
		public Choice HumanChoice {get; set;}
		
	}
}

