using System;

namespace AppLifecycle
{
	public class UpdatingEventArgs : EventArgs
	{
		public string Message;
	}
}

