using System;

namespace AppLifecycle.Services
{
	public class UpdatingEventArgs : EventArgs
	{
		public string Message;
	}
}

