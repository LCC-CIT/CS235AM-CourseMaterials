using System;
using MonoTouch.UIKit;

namespace EvolveLite
{
	public class Speaker
	{
		public UIImage Image { get; set; }

		public string Name { get; set; }

		public string Company { get; set; }

		public Speaker ()
		{
		}
	}
}

