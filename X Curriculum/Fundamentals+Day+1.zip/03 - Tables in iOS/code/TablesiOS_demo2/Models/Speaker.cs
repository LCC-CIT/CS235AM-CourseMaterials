using System;
using MonoTouch.UIKit;

namespace EvolveLite
{
	public class Speaker
	{
		public string HeadshotUrl { get; set; }

		public string Name { get; set; }

		public string Company { get; set; }

		public string TwitterHandle { get; set; }

		public Speaker ()
		{
		}
	}
}

