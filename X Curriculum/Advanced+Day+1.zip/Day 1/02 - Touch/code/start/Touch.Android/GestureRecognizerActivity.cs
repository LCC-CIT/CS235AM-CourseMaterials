namespace TouchWalkthrough
{
    using Android.App;
    using Android.OS;
    using Android.Views;

    [Activity(Label = "@string/activity_gesture_recognizer")]
    public class GestureRecognizerActivity : Activity
    {
/*
        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);
            View v = new GestureRecognizerView(this);
            SetContentView(v);
        }
*/
    }
}
