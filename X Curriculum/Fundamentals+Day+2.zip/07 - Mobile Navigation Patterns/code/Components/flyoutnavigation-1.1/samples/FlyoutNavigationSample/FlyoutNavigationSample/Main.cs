using System;

using MonoTouch.UIKit;
using MonoTouch.Foundation;

namespace Sample
{
	public class Application
	{
		static void Main (string[] args)
		{
			UIApplication.Main (args, null, "AppDelegate");
		}
	}
}
