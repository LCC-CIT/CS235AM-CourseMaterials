There are two projects included with this solution.

Honeycomb is the project that shows fragments on devices running Android 3.1 or higher.

AllAndroid is the project that shows fragments on devices running Android 1.6 or higher.