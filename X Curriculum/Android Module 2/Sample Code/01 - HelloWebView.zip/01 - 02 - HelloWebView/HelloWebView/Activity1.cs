using System;

using Android.App;
using Android.Content;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.OS;

namespace HelloWebView
{
    [Activity (Label = "HelloWebView", MainLauncher = true, Theme="@android:style/Theme.NoTitleBar")]
    public class Activity1 : Activity
    {
        private Android.Webkit.WebView _webView;

        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);

            // Set our view from the "main" layout resource
            SetContentView(Resource.Layout.Main);

            _webView = FindViewById<Android.Webkit.WebView>(Resource.Id.webview);
            _webView.Settings.JavaScriptEnabled = true;

            _webView.SetWebViewClient(new HelloWebViewClient());

            _webView.LoadUrl("http://forums.xamarin.com");
        }

        public override bool OnKeyDown(Keycode keyCode, KeyEvent e)
        {
            if (Keycode.Back.Equals(keyCode) && _webView.CanGoBack()) {
                _webView.GoBack();
                return true;
            }
            return base.OnKeyDown(keyCode, e);
        }
    }
}


