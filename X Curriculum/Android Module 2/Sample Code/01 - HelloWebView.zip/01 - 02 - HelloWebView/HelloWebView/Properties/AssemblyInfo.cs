using System.Reflection;
using System.Runtime.CompilerServices;
using Android.App;

[assembly: AssemblyTitle("HelloWebView")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("")]
[assembly: AssemblyCopyright("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: AssemblyVersion("1.0.0")]

[assembly: Android.App.UsesPermission(Android.Manifest.Permission.Internet)]

