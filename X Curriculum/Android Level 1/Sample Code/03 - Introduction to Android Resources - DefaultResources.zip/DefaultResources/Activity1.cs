using System;

using Android.App;
using Android.Content;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.OS;

namespace DefaultResources
{
    [Activity (Label = "DefaultResources", MainLauncher = true)]
    public class Activity1 : Activity
    {
        int count = 1;

        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);

            SetContentView(Resource.Layout.Main);

            Button button = FindViewById<Button>(Resource.Id.myButton);
            ImageView image = FindViewById<ImageView>(Resource.Id.myImageView);
    
            button.Click += delegate
            {
                if (count % 2 == 0)
                {
                    image.SetImageResource(Resource.Drawable.flag_even);
                } else
                {
                    image.SetImageResource(Resource.Drawable.flag_odd);
                }
                button.Text = GetString(Resource.String.button_clicked_text, count++);
            };
        }
    }
}

