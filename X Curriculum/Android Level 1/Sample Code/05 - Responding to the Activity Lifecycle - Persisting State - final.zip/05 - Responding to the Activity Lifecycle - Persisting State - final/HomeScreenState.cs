﻿namespace PersistStateWalkthrough
{
    using System.Collections.Generic;

    public class HomeScreenState: Java.Lang.Object 
    {
        public HomeScreenState(List<Flora> list)
        {
            ListOfFlora = list;
        }

        public List<Flora> ListOfFlora { get; private set; }
    }
}
