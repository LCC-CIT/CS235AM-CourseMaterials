namespace PersistStateWalkthrough
{
    using System;
    using System.Collections.Generic;
    using System.Threading;

    using Android.App;
    using Android.OS;
    using Android.Widget;

    using Object = Java.Lang.Object;

    [Activity(Label = "Persist State", MainLauncher = true, Icon = "@drawable/icon")]
    public class HomeScreen : Activity
    {
        private List<Flora> listOfFlora = new List<Flora>();
        private ListView listView;
        private TextView lastSelectedFloraText;
        private int selectedPosition = -1;

        public override Object OnRetainNonConfigurationInstance()
        {
            return new HomeScreenState(listOfFlora);
        }

        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);

            SetContentView(Resource.Layout.HomeScreen);
            listView = FindViewById<ListView>(Resource.Id.List);
            lastSelectedFloraText = FindViewById<TextView>(Resource.Id.selected_flora);

            var previousState = LastNonConfigurationInstance as HomeScreenState;
            if (previousState == null)
            {
                LoadFloraList();
            } else
            {
                listOfFlora = previousState.ListOfFlora;
            }

            listView.Adapter = new HomeScreenAdapter(this, listOfFlora);
            listView.ItemClick += OnListItemClick;
            if (bundle != null)
            {
                selectedPosition = bundle.GetInt("listview_selecteditemposition", -1);
            }
        }

        protected override void OnResume()
        {
            base.OnResume();
            DisplayLastSelectedFlora();
            // This will cause the list to scroll so that the selected item is in the view.
            listView.SetSelection(selectedPosition);
        }

        protected void OnListItemClick(object sender, AdapterView.ItemClickEventArgs e)
        {
            selectedPosition = e.Position;
            DisplayLastSelectedFlora();
        }

        protected override void OnSaveInstanceState(Bundle outState)
        {
            base.OnSaveInstanceState(outState);
            outState.PutInt("listview_selecteditemposition", selectedPosition);
        }

        private void DisplayLastSelectedFlora()
        {
            if (selectedPosition > -1)
            {
                var flora = listOfFlora [selectedPosition];
                lastSelectedFloraText.Text = "Selected flora : " + flora.Name;
            }
        }

        private void LoadFloraList()
        {
            listOfFlora.Add(new Flora { Name = "Vegetables", ItemCount = "65 items", ImageResourceId = Resource.Drawable.Vegetables });
            listOfFlora.Add(new Flora { Name = "Fruits", ItemCount = "17 items", ImageResourceId = Resource.Drawable.Fruits });
            listOfFlora.Add(new Flora { Name = "Flower Buds", ItemCount = "5 items", ImageResourceId = Resource.Drawable.FlowerBuds });

            // Pretend that creating this list takes a long time.
            Thread.Sleep(2500);

            listOfFlora.Add(new Flora { Name = "Legumes", ItemCount = "33 items", ImageResourceId = Resource.Drawable.Legumes });
            listOfFlora.Add(new Flora { Name = "Bulbs", ItemCount = "18 items", ImageResourceId = Resource.Drawable.Bulbs });
            listOfFlora.Add(new Flora { Name = "Tubers", ItemCount = "43 items", ImageResourceId = Resource.Drawable.Tubers });
        }
    }
}
